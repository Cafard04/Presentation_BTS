<?php
declare(strict_types=1);

namespace App\Test\TestCase\Model\Table;

use App\Model\Table\CommandsProductsTable;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\CommandsProductsTable Test Case
 */
class CommandsProductsTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\CommandsProductsTable
     */
    protected $CommandsProducts;

    /**
     * Fixtures
     *
     * @var array
     */
    protected $fixtures = [
        'app.CommandsProducts',
        'app.Products',
        'app.Commands',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp(): void
    {
        parent::setUp();
        $config = $this->getTableLocator()->exists('CommandsProducts') ? [] : ['className' => CommandsProductsTable::class];
        $this->CommandsProducts = $this->getTableLocator()->get('CommandsProducts', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown(): void
    {
        unset($this->CommandsProducts);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test buildRules method
     *
     * @return void
     */
    public function testBuildRules(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
