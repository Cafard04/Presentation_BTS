<?php
declare(strict_types=1);

namespace App\Test\TestCase\Model\Table;

use App\Model\Table\TvasTable;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\TvasTable Test Case
 */
class TvasTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\TvasTable
     */
    protected $Tvas;

    /**
     * Fixtures
     *
     * @var array
     */
    protected $fixtures = [
        'app.Tvas',
        'app.ProductsProviders',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp(): void
    {
        parent::setUp();
        $config = $this->getTableLocator()->exists('Tvas') ? [] : ['className' => TvasTable::class];
        $this->Tvas = $this->getTableLocator()->get('Tvas', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown(): void
    {
        unset($this->Tvas);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
