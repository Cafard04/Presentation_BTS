<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * ProductsProvidersFixture
 */
class ProductsProvidersFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // phpcs:disable
    public $fields = [
        'provider_id' => ['type' => 'integer', 'length' => null, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null, 'autoIncrement' => null],
        'product_id' => ['type' => 'integer', 'length' => null, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null, 'autoIncrement' => null],
        'tva_id' => ['type' => 'integer', 'length' => null, 'unsigned' => false, 'null' => false, 'default' => '1', 'comment' => '', 'precision' => null, 'autoIncrement' => null],
        'price' => ['type' => 'decimal', 'length' => 10, 'precision' => 3, 'unsigned' => false, 'null' => false, 'default' => '-1.000', 'comment' => ''],
        '_indexes' => [
            'fk_providers_has_products_products1_idx' => ['type' => 'index', 'columns' => ['product_id'], 'length' => []],
            'fk_providers_has_products_providers1_idx' => ['type' => 'index', 'columns' => ['provider_id'], 'length' => []],
            'fk_products_providers_tvas1_idx' => ['type' => 'index', 'columns' => ['tva_id'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['provider_id', 'product_id'], 'length' => []],
            'fk_providers_has_products_providers1' => ['type' => 'foreign', 'columns' => ['provider_id'], 'references' => ['providers', 'id'], 'update' => 'noAction', 'delete' => 'noAction', 'length' => []],
            'fk_providers_has_products_products1' => ['type' => 'foreign', 'columns' => ['product_id'], 'references' => ['products', 'id'], 'update' => 'noAction', 'delete' => 'noAction', 'length' => []],
            'fk_products_providers_tvas1' => ['type' => 'foreign', 'columns' => ['tva_id'], 'references' => ['tvas', 'id'], 'update' => 'noAction', 'delete' => 'noAction', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'utf8_general_ci'
        ],
    ];
    // phpcs:enable
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'provider_id' => 1,
                'product_id' => 1,
                'tva_id' => 1,
                'price' => 1.5,
            ],
        ];
        parent::init();
    }
}
