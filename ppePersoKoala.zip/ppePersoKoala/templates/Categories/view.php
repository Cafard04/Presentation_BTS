<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Category $category
 */
?>


<style>
a{
    color: grey; 
}
</style>



<div class="row">
    <aside class="column">
        <div class="side-nav pl-3">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <i class="fas fa-edit" ></i> &nbsp; <?= $this->Html->link(__('Editer'), ['action' => 'edit', $category->id], ['class' => 'side-nav-item']) ?> &emsp;
            <i class="fas fa-trash"></i> &nbsp; <?= $this->Form->postLink(__('Supprimer'), ['action' => 'delete', $category->id], ['confirm' => __('Etes vous certain de vouloir supprimer la catégorie {0} ?', $category->name), 'class' => 'side-nav-item']) ?>&emsp;
            <i class="fas fa-stream"></i> &nbsp; <?= $this->Html->link(__('Liste'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>&emsp;
            <i class="fas fa-sort-alpha-up"></i> &nbsp; <?= $this->Html->link(__('Créer'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="categories view content" style="margin:15px; padding-top:5%">
            <table>
                <tr>
                    <th><?= __('Dénomination') ?></th>
                    <td><?= h($category->name) ?></td>
                </tr>
            </table>
            <hr>
            <div class="related" style="padding-top:5%">
                <h4><?= __('Produits liés') ?></h4>
                <?php if (!empty($category->products)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Dénomination') ?></th>
                            <th><?= __('Quantité') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($category->products as $products) : ?>
                        <tr>
                            <td><?= h($products->name) ?></td>
                            <td><?= h($products->stock) ?></td>
                            <td class="actions">
                                <a href="<?= $this->Url->build(['controller' => 'Products','action' => 'view', $products->id]); ?>"><i class="fas fa-eye"></i></a>&emsp;
                                <a href="<?= $this->Url->build(['controller' => 'Products','action' => 'edit', $products->id]); ?>"><i class="fas fa-edit"></i></a>&emsp;
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
