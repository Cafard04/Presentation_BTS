<html class="">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?= $this->fetch('title') ?></title>
        <script defer src="https://use.fontawesome.com/releases/v5.3.1/js/all.js"></script>		
        <link rel="stylesheet" href="https://www.jsdelivr.com/package/npm/@creativebulma/bulma-divider">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.0/css/bulma.min.css" integrity="sha256-aPeK/N8IHpHsvPBCf49iVKMdusfobKo2oxF8lRruWJg=" crossorigin="anonymous">
        <script defer src="https://use.fontawesome.com/releases/v5.3.1/js/all.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@creativebulma/bulma-divider@1.1.0/dist/bulma-divider.min.css">
        <?= $this->Html->script('toast.js') ?>
    </head>
    <style>
        body{
    background: rgb(242,235,241);
background: linear-gradient(90deg, rgba(242,235,241,1) 0%, rgba(246,244,219,0.8600866494058561) 18%, rgba(209,245,252,0.5435600387615984) 100%);
}
    </style>
    <body>
        <?= $this->Flash->render() ?>
        <main>
            <section class="">
                <!--                <div class="hero-body">   -->
                <div class="container is-fluid " style="padding: 0; ">

                    <div class="columns " style="margin: 0px;">
                        <!--
<div class="box column p-0 is-full">
<div class="columns">
-->
<div class="columns is-mobile" style="min-height: 100vh; width:80%">
            <div class="menu column is-one-fifth m-5" style="margin:2%">
                <aside class="menu">
                    <p class="menu-label">
                        Général
                    </p>
                    <ul class="menu-list">
                        <li><a href="<?= $this->Url->build(["controller" => "Users","action" => "accueil",]); ?>"> <i class="fas fa-home"></i> &nbsp; Accueil</a></li>
                        <li><a  href="<?= $this->Url->build(['controller' => 'Users','action' => 'view',$auth['id']]) ?>"> <i class="fas fa-user"></i> &nbsp; Profil</a></li>
                    </ul>
                    <p class="menu-label">
                    Gestion des produits
                    </p>
                    <ul class="menu-list">
                        <ul>
                            <li><a href="<?= $this->Url->build(['controller' => 'Products','action' => 'index']); ?>">Liste des produits</a></li>
                            <li><a href="<?= $this->Url->build(['controller' => 'Products','action' => 'add']); ?>">Ajouter un produit</a></li>
                            
                            <li><a href="<?= $this->Url->build(['controller' => 'Categories','action' => 'index']); ?>">Catégories</a></li>
                            <li><a href="<?= $this->Url->build(['controller' => 'Units','action' => 'index']); ?>">Unités de mesure</a></li>
                            <li><a href="<?= $this->Url->build(['controller' => 'Tvas','action' => 'index']); ?>">Taux de TVA</a></li>
                        </ul>
                    </ul>

                 
                    <?php if($auth['role_id'] === 1){
                        echo "<p class='menu-label'>
                        Gestion des utilisateurs
                        </p>
                        <ul class='menu-list'>
                            <ul>
                                <li><a href=".$this->Url->build(['controller' => 'Users','action' => 'index']).">Liste des utilisateurs</a></li>
                                <li><a href=".$this->Url->build(['controller' => 'Users','action' => 'add']).">Ajouter un utilisateur</a></li>
                            </ul>
                        </ul>";
                    }

                    ?>
                    
                    <p class="menu-label">
                    Gestion des fournisseurs
                    </p>
                    <ul class="menu-list">
                        <ul>
                            <li><a href="<?= $this->Url->build(['controller' => 'Providers','action' => 'index']); ?>">Liste des fournisseurs</a></li>
                            <li><a href="<?= $this->Url->build(['controller' => 'Providers','action' => 'add']); ?>">Ajouter un fournisseur</a></li>
                            <li><a href="<?= $this->Url->build(['controller' => 'Commands','action' => 'index']); ?>">Commandes</a></li>
                        </ul>
                    </ul>

                    <?php if(isset($auth['role_id'])):  ?>
                    <a  href="<?= $this->Url->build(['controller' => 'Users', 'action' => 'logout']); ?>" class="navbar-item" style="margin-top:50%; color:grey;">
                        <i class="fas fa-user-slash"></i> &nbsp; Déconnexion
                    </a>
                <?php endif; ?>
                </aside>
                
            </div>

                        <div class="column is-full ml-5" style="background-color:white;">
                            <?= $this->fetch('content');?>
                        </div>





                    </div>

                </div>
               
            </section>
        </main>
    </body>
</html>