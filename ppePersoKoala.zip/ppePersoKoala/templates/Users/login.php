<!-- <html>
    <head>


        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.1/css/bulma.min.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.1/css/all.min.css" />

        <link rel="stylesheet" href="style.css">

    </head>
    <body> -->

<style>
div.centre {
    position:absolute;
    left: 50%;
    top: 50%;
    width: 500px;
    height: 500px;
    margin-left: -250px; /* Cette valeur doit être la moitié négative de la valeur du width */
    margin-top: -250px; /* Cette valeur doit être la moitié négative de la valeur du height */
    background-color: white;
}
body{
    background: rgb(242,235,241);
background: linear-gradient(90deg, rgba(242,235,241,1) 0%, rgba(246,244,219,0.8600866494058561) 18%, rgba(209,245,252,0.5435600387615984) 100%);
}
a{
    color: grey; 
}
</style>
    <?= $this->Form->create() ?>
        <div class="centre">
            <form class="box" style="width:450px ;height : 450px">
                <div class="p-5">
                    <p class="subtitle is-4 has-text-weight-bold"><i class="fas fa-qrcode fa-lg"></i> &ensp; KoalaStock</p> 
                    <p class=""><a href="<?= $this->Url->build(["controller" => "Users","action" => "accueil",]); ?>"><i class="fas fa-home fa-sm"></i> &ensp; Accueil</a></p> 
                    <hr>
                    <div class="field">
                        <label class="label">Email</label>
                        <div class="control">
                            <input class="input" type="email" name="email" placeholder="alex@example.com" required="">
                        </div>
                    </div>

                    <div class="field pb-5">
                        <label class="label">Password</label>
                        <div class="control">
                            <input class="input" type="password" name="password" placeholder="********" required="">
                        </div>
                    </div>

                    <button class="button is-primary">Sign in</button>
                </div>

            </form>
        </div>
<?= $this->Form->end() ?>
    <!-- </body>
</html> -->
