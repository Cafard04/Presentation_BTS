<?php
$this->Form->setTemplates([

	'input' => '<div class="control "><input class="input" type="{{type}}" name="{{name}}"{{attrs}}/></div>',

	'inputContainer' => '<div info="{{type}}" class="field  {{required}}">{{content}}</div>',
	// Container element used by control() when a field has an error.
	// Label element when inputs are not nested inside the label.
	'label' => '<label class="label" {{attrs}}>{{text}}</label>',
    'button' => '<button class="button is-link mt-3" {{attrs}}>{{text}}</button>',
	// Container for submit buttons.
	'submitContainer' => '<div class="submit field">{{content}}</div>',
	// select element,
	'select' => '<div class="select is-fullwidth"><select name="{{name}}"{{attrs}}>{{content}}</select> </div>',

]);
?>
<style>
a{
    color: grey; 
}
</style>
<div class="row">
    <div class="user column is-full" style="padding-top:5%">
        
    <legend class="subtitle"><?= __('Statistiques') ?></legend>
            Nous avons des partenariat avec <td><?= $data ?></td> fournisseurs.
            <br>
            Nous proposons .... produits.

            <?php
     if($data) {
          echo "zzzzz<pre>";
          print_r($data);
     } else {
          echo 'no data found';
     }
?>




            <!-- <table>
                <tr>
                    <td><?= h($provider->name) ?></td>
                </tr>
            </table> -->


            <!-- <?= $this->Form->create($user) ?>
            <fieldset>
                <legend class="subtitle"><?= __('Statistiques') ?></legend>
                <?php
                    echo $this->Form->control('name',['label' => 'Prénom']);
                ?>
            </fieldset>
            <?= $this->Form->button(__('Créer')) ?>
            <?= $this->Form->end() ?> -->
        
    </div>
</div>


<!-- SELECT DISTINCT COUNT(id) FROM providers -->

<!-- SELECT DISTINCT COUNT(id) FROM products; -->

<!-- SELECT DISTINCT COUNT(products_providers.product_id), products_providers.provider_id, providers.name FROM products_providers, providers
WHERE products_providers.provider_id = providers.id
GROUP BY products_providers.provider_id ; -->

<!-- SELECT DISTINCT COUNT(commands.id), commands.provider_id, providers.name FROM commands, providers
WHERE commands.provider_id = providers.id
GROUP BY commands.provider_id ; -->
