<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\User $user
 */
?>

<style>
a{
    color: grey; 
}
</style>
<div class="row">
    <aside class="column">
        <div class="side-nav pl-3">
            
            <?php if($auth['role_id'] === 1){
                echo "<h4 class='heading'>".__('Actions')."</h4>";
                echo "<i class='fas fa-user-edit' ></i> &nbsp;".$this->Html->link(__('Editer'), ['action' => 'edit', $user->id], ['class' => 'side-nav-item'])."&emsp;";
                
                if($auth['id'] != $user['id']){
                    echo "<i class='fas fa-user-minus'></i> &nbsp;".$this->Form->postLink(__('Supprimer'), ['action' => 'delete', $user->id], ['confirm' => __('Etes vous certain de vouloir supprimer l\'utilisateur {0} {1} ?', $user->name, $user->last_name), 'class' => 'side-nav-item'])."&emsp;";
                }
                echo "<i class='fas fa-users'></i> &nbsp;".$this->Html->link(__('Liste'), ['action' => 'index'], ['class' => 'side-nav-item'])."&emsp;";
                echo "<i class='fas fa-user-plus'></i> &nbsp;".$this->Html->link(__('Créer'), ['action' => 'add'], ['class' => 'side-nav-item']);
        
            }
            ?>
            </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="users view content" style="margin:15px; padding-top:5%">
            <h3 class="pl-3"><?= h($user->name)?> <?= h($user->last_name)?></h3>
            <table>
                <tr>
                    <th><?= __('Email') ?></th>
                    <td><?= h($user->email) ?></td>
                </tr>
                <tr>
                    <th><?= __('Password') ?></th>
                    <td><?= h($user->password) ?></td>
                </tr>
                <tr>
                    <th><?= __('Role') ?></th>
                    <td><?= $user->has('role') ? $this->Html->link($user->role->name, ['controller' => 'Roles', 'action' => 'view', $user->role->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Name') ?></th>
                    <td><?= h($user->name) ?></td>
                </tr>
                <tr>
                    <th><?= __('Last Name') ?></th>
                    <td><?= h($user->last_name) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($user->id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Create Time') ?></th>
                    <td><?= h($user->create_time) ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
