

    <body>
        <div class="centre">
            <div class="columns is-vcentered">
                <div class="column is-6">
                    <span>KoalaStock</span>
                    <h5 class="title pt-5">Gestion d'inventaire et de fournisseurs</h5>
                </div>
                <figure class="image" style="width : 30%; padding-bottom : 10%; text-align: center;">
                    <?= $this->Html->image('home.png', ['alt' => 'CakePHP']); ?>
                </figure>

            </div>
        </div>




    </body>


<style>


    div.centre {
        position:absolute;
        left: 25%;
        right: 10%;
        top: 50%;
        width: auto;
        height: 200px;
        margin-left: -100px; /* Cette valeur doit être la moitié négative de la valeur du width */
        margin-top: -100px; /* Cette valeur doit être la moitié négative de la valeur du height */
        font-size: 75px
    }


    .overlay-image .hover {
        position: absolute;
        top: 0;
        height: 100%;
        width: 100%;
        opacity: 0;
        transition: .5s ease;
    }
    /* Apparition overlay sur passage souris */
    .overlay-image:hover .hover {
        opacity: 1;
    }

    .overlay-image {
        position: relative;
        width: 100%;
    }
    /* Image originale */
    .overlay-image .image {
        display: block;
        width: 100%;
        height: auto;
    }
    /* Texte original */
    .overlay-image .text {
        color: #fff;
        font-size: 15px;
        line-height: 1.5em;
        text-shadow: 2px 2px 2px #000;
        text-align: justify;
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 100%;
    }

    .overlay-image .normal {
        transition: .5s ease;
    }
    .overlay-image:hover .normal {
        opacity: 0;
    }
    .overlay-image .hover {
        background-color: rgba(0,0,0,0.5);



</style>