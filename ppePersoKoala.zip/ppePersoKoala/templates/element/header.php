<!DOCTYPE html>
<!--if( isset($auth['role_id']) && ( $auth['role_id'] == 3 || $auth['role_id'] == 4 || $auth['role_id'] == 2)): -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma@0.9.2/css/bulma.min.css">
  
<header>


    <div class="hero-head">
        <nav class="navbar  is-light">
            <div class="container">
                <div class="navbar-brand ">
                    <a class="navbar-item ">
                        <h1 class="title pt-2">
                        <i class="fas fa-qrcode"></i> &nbsp;KoalaStock </h1>


                    </a>
                    <span class="navbar-burger burger" data-target="navbarMenuHeroB">
                        <span></span>
                        <span></span>
                        <span></span>
                    </span>
                </div>
                <div id="navbarMenuHeroB" class="navbar-menu ">
                    
                    
                    <div class="navbar-end is-active">

                        <?php if(!isset($auth['role_id'])):  ?>
                        <a href="<?= $this->Url->build(['controller' => 'Users', 'action' => 'login']); ?>" class="navbar-item">
                            Connexion
                        </a>
                        <?php endif; ?>
                        
                         <?php if(isset($auth['role_id'])):  ?>
                        <a href="<?= $this->Url->build(['controller' => 'Users', 'action' => 'logout']); ?>" class="navbar-item">
                            Déconnexion
                        </a>
                        <?php endif; ?>
                        
                    </div>
                    
                   
    
                    
                    <?php if( isset($auth['id'])): ?>
                    <div class="navbar-item has-dropdown is-hoverable">
                        <a class="navbar-link is-arrowless">
                           <?=  $this->request->getSession()->read('user.role'); ?>
                        </a>
                        <div class="navbar-dropdown">
                            <a href="<?= $this->Url->build(['controller' => 'Users','action' => 'view',$auth['id']]) ?>" class="navbar-item">
                                Mon espace de gestion
                            </a>
                            <a href="<?= $this->Url->build(['controller' => 'Users','action' => 'stat',$auth['id']]) ?>" class="navbar-item">
                                Statistiques
                            </a>
                                   <?php if( $auth['role_id'] === 1 ): ?>
                            
                                   <?php endif; ?>
                            
                            <hr class="navbar-divider">
                            <div class="navbar-item">
                                <?= $auth['name'] ?> <?= $auth['last_name'] ?> - <?=  $this->request->getSession()->read('user.role'); ?>
                            </div>
                        </div>
                    </div>
                     <?php endif; ?>
                    
                    
        
                    

                </div>
            </div>
        </nav>
    </div>

</header>



