<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\CommandsProduct $commandsProduct
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Commands Product'), ['action' => 'edit', $commandsProduct->product_id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Commands Product'), ['action' => 'delete', $commandsProduct->product_id], ['confirm' => __('Are you sure you want to delete # {0}?', $commandsProduct->product_id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Commands Products'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Commands Product'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="commandsProducts view content">
            <h3><?= h($commandsProduct->product_id) ?></h3>
            <table>
                <tr>
                    <th><?= __('Product') ?></th>
                    <td><?= $commandsProduct->has('product') ? $this->Html->link($commandsProduct->product->name, ['controller' => 'Products', 'action' => 'view', $commandsProduct->product->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Command') ?></th>
                    <td><?= $commandsProduct->has('command') ? $this->Html->link($commandsProduct->command->id, ['controller' => 'Commands', 'action' => 'view', $commandsProduct->command->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Qtt') ?></th>
                    <td><?= $this->Number->format($commandsProduct->qtt) ?></td>
                </tr>
                <tr>
                    <th><?= __('Price') ?></th>
                    <td><?= $this->Number->format($commandsProduct->price) ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
