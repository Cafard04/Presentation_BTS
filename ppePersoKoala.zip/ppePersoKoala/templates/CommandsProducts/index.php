<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\CommandsProduct[]|\Cake\Collection\CollectionInterface $commandsProducts
 */
?>
<div class="commandsProducts index content">
    <?= $this->Html->link(__('New Commands Product'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Commands Products') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('product_id') ?></th>
                    <th><?= $this->Paginator->sort('command_id') ?></th>
                    <th><?= $this->Paginator->sort('qtt') ?></th>
                    <th><?= $this->Paginator->sort('price') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($commandsProducts as $commandsProduct): ?>
                <tr>
                    <td><?= $commandsProduct->has('product') ? $this->Html->link($commandsProduct->product->name, ['controller' => 'Products', 'action' => 'view', $commandsProduct->product->id]) : '' ?></td>
                    <td><?= $commandsProduct->has('command') ? $this->Html->link($commandsProduct->command->id, ['controller' => 'Commands', 'action' => 'view', $commandsProduct->command->id]) : '' ?></td>
                    <td><?= $this->Number->format($commandsProduct->qtt) ?></td>
                    <td><?= $this->Number->format($commandsProduct->price) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $commandsProduct->product_id]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $commandsProduct->product_id]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $commandsProduct->product_id], ['confirm' => __('Are you sure you want to delete # {0}?', $commandsProduct->product_id)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
