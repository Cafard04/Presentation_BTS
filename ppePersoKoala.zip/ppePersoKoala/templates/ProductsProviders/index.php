<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\ProductsProvider[]|\Cake\Collection\CollectionInterface $productsProviders
 */
?>
<div class="productsProviders index content">
    <?= $this->Html->link(__('New Products Provider'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Products Providers') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('provider_id') ?></th>
                    <th><?= $this->Paginator->sort('product_id') ?></th>
                    <th><?= $this->Paginator->sort('tva_id') ?></th>
                    <th><?= $this->Paginator->sort('price') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($productsProviders as $productsProvider): ?>
                <tr>
                    <td><?= $productsProvider->has('provider') ? $this->Html->link($productsProvider->provider->name, ['controller' => 'Providers', 'action' => 'view', $productsProvider->provider->id]) : '' ?></td>
                    <td><?= $productsProvider->has('product') ? $this->Html->link($productsProvider->product->name, ['controller' => 'Products', 'action' => 'view', $productsProvider->product->id]) : '' ?></td>
                    <td><?= $productsProvider->has('tva') ? $this->Html->link($productsProvider->tva->name, ['controller' => 'Tvas', 'action' => 'view', $productsProvider->tva->id]) : '' ?></td>
                    <td><?= $this->Number->format($productsProvider->price) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $productsProvider->provider_id,$productsProvider->product_id]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $productsProvider->provider_id,$productsProvider->product_id]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $productsProvider->provider_id,$productsProvider->product_id], ['confirm' => __('Are you sure you want to delete # {0}?', $productsProvider->provider_id)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
