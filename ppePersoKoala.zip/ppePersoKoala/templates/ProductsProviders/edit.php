<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\ProductsProvider $productsProvider
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Form->postLink(
                __('Delete'),
                // ['action' => 'delete', $productsProvider->provider_id],
                // ['confirm' => __('Are you sure you want to delete # {0}?', $productsProvider->provider_id), 'class' => 'side-nav-item']
            ) ?>
            <?= $this->Html->link(__('List Products Providers'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="productsProviders form content">
            <?= $this->Form->create($productsProvider) ?>
            <fieldset>
                <legend><?= __('Edit Products Provider') ?></legend>
                <?php
                    echo $this->Form->control('tva_id', ['options' => $tvas]);
                    echo $this->Form->control('price',['value' => $productsProvider[0]->price]);
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
