<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\ProductsProvider $productsProvider
 */
?>
<div class="row">
    <div class="column-responsive ">
        <div class="productsProviders view content">
            <h3><?= h($productsProvider->provider_id) ?></h3>
            <table>
                <tr>
                    <th><?= __('Provider') ?></th>
                    <td><?= $productsProvider->has('provider') ? $this->Html->link($productsProvider->provider->name, ['controller' => 'Providers', 'action' => 'view', $productsProvider->provider->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Product') ?></th>
                    <td><?= $productsProvider->has('product') ? $this->Html->link($productsProvider->product->name, ['controller' => 'Products', 'action' => 'view', $productsProvider->product->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Tva') ?></th>
                    <td><?= $productsProvider->has('tva') ? $this->Html->link($productsProvider->tva->name . " %", ['controller' => 'Tvas', 'action' => 'view', $productsProvider->tva->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Price') ?></th>
                    <td><?= $this->Number->format($productsProvider->price) ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
