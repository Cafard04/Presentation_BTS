<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Command $command
 */
?>

<style>
a{
    color: grey; 
}
</style>

<div class="row">
    <aside class="column">
        <div class="side-nav pl-3">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <!-- <i class="fas fa-edit" ></i> &nbsp; <?= $this->Html->link(__('Editer'), ['action' => 'edit', $command->id], ['class' => 'side-nav-item']) ?> &emsp; -->
            <i class="fas fa-trash"></i> &nbsp; <?= $this->Form->postLink(__('Supprimer'), ['action' => 'delete', $command->id], ['confirm' => __('Etes vous certain de vouloir supprimer la commande {0} ?', $command->name), 'class' => 'side-nav-item']) ?>&emsp;
            <i class="fas fa-stream"></i> &nbsp; <?= $this->Html->link(__('Liste'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>&emsp;
            <i class="fas fa-user-tie"></i> &nbsp; <?= $this->Html->link(__('Créer'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="commands view content" style="margin:15px; padding-top:5%">
            <table>
                <tr>
                    <th><?= __('Fournisseur') ?></th>
                    <td><?= $command->has('provider') ? $this->Html->link($command->provider->name, ['controller' => 'Providers', 'action' => 'view', $command->provider->id]) : '' ?></td>
                </tr>

            </table>
            <div class="related" style="padding-top:5%">
                <h4><?= __('Produits liés') ?></h4>
                <?php if (!empty($command->products)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Nom') ?></th>
                            <th><?= __('Num. catégorie') ?></th>
                            <th><?= __('Stock commandé') ?></th>
                            <th><?= __('Remise') ?></th>
                            <th><?= __('Total €') ?></th>
                            <th><?= __('Num. unité') ?></th>
                            <!-- <th class="actions"><?= __('Actions') ?></th> -->
                        </tr>
                        <?php foreach ($command->products as $products) : ?>
                        <tr>
                            <td><?= h($products->name) ?></td>
                            <td><?= h($products->category->name) ?></td>
                            <td><?= h($products->_joinData->qtt) ?></td>
                            <?php if (($products->_joinData->qtt) >= 10) : ?>
                                <td><?= "-",h($products->_joinData->price)*0.05,"€"?></td>
                                <?php endif; ?>

                            <?php if (($products->_joinData->qtt) < 10) : ?>
                            <td><?= "-"?></td>
                            <?php endif; ?>

                            <td><?= h($products->_joinData->price) ?></td>
                            <td><?= h($products->unit->name) ?></td>
                            <!-- <td class="actions">
                                <?= $this->Html->link(__('View'), ['controller' => 'Products', 'action' => 'view', $products->id]) ?>
                                <?= $this->Html->link(__('Edit'), ['controller' => 'Products', 'action' => 'edit', $products->id]) ?>
                                <?= $this->Form->postLink(__('Delete'), ['controller' => 'Products', 'action' => 'delete', $products->id], ['confirm' => __('Are you sure you want to delete # {0}?', $products->id)]) ?>
                            </td> -->
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
