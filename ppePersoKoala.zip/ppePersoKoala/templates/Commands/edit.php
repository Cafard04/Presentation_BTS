<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Command $command
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Form->postLink(
                __('Delete'),
                ['action' => 'delete', $command->id],
                ['confirm' => __('Are you sure you want to delete # {0}?', $command->id), 'class' => 'side-nav-item']
            ) ?>
            <?= $this->Html->link(__('List Commands'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="commands form content">
            <?= $this->Form->create($command) ?>
            <fieldset>
                <legend><?= __('Edit Command') ?></legend>
                <?php
                    echo $this->Form->control('provider_id', ['options' => $providers]);
                    echo $this->Form->control('products._ids', ['options' => $products]);
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
