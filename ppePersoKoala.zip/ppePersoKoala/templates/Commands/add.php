<?php
$this->Form->setTemplates([

	'input' => '<div class="control "><input class="input" type="{{type}}" name="{{name}}"{{attrs}}/></div>',

	'inputContainer' => '<div info="{{type}}" class="field  {{required}}">{{content}}</div>',
	// Container element used by control() when a field has an error.
	// Label element when inputs are not nested inside the label.
	'label' => '<label class="label" {{attrs}}>{{text}}</label>',
    'button' => '<button class="button is-link mt-3" {{attrs}}>{{text}}</button>',
	// Container for submit buttons.
	'submitContainer' => '<div class="submit field">{{content}}</div>',
	// select element,
	'select' => '<div class="select is-fullwidth"><select name="{{name}}"{{attrs}}>{{content}}</select> </div>',

]);
?>
<style>
a{
    color: grey; 
}
</style>


<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <i class="fas fa-stream"></i> &nbsp; <?= $this->Html->link(__('Liste'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>&emsp;
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="commands column is-full" style="padding-top:5%;">
            <?= $this->Form->create($command) ?>
            <fieldset>
                <legend class="subtitle"><?= __('Référencer une commande chez <b>'.$providers->name.'</b>') ?></legend>
                
            </fieldset>

            <button  class="button is-info is-light" style="margin-top:5%; margin-bottom:5%;" type="button" id="btnadd">Ajouter un produit</button>
            
            <table class="table is-striped is-fullwidth">
			<thead>
				<tr>
					<th>Produits</th>
					<th>Quantité</th>
					<th></th>
				</tr>
			</thead>
			<tbody id="table">

			</tbody>
		</table>



            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>



<script>
	const varhtml = ` 
<tr id="ing&i">
<td><?= $this->Form->control('products.&i.id',['label'=>false,'type' => 'select','options' => $products,'multiple' => false]); ?></td>
<td><?= $this->Form->control('products.&i._joinData.qtt',['label'=>false]); ?></td>
<td ><button type="button" idd="&i" class="ingbtn" style="margin-top:5%;"><i class="fas fa-trash"></i></button></td>
	</tr> `;

	var i =  0;
	$('#btnadd').on('click',function(){
		$('#table').append(varhtml.replace(/(&i)/g,i));
		i++;
	});
	$(document).on("click", ".ingbtn", function() {
		$('#ing'+$(this).attr('idd')).remove();
	});

</script>