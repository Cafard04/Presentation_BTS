<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Command[]|\Cake\Collection\CollectionInterface $commands
 */
?>

<style>
a{
    color: grey; 
}
</style>

<div class="commands index content">
    <aside class="column">
        <div class="side-nav">
        <i class="fas fa-shopping-basket"></i> &nbsp; <?= $this->Html->link(__('Créer'), ['controller' => 'providers'] ,  ['action' => 'add'], ['class' => 'side-nav-item']) ?>&emsp;
        </div>
    </aside>
    <h3><?= __('Commandes en cours ') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id',['label' => 'Num. commande']) ?></th>
                    <th><?= $this->Paginator->sort('provider_id',['label' => 'Fournisseur']) ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($commands as $command): ?>
                <tr>
                    <td><?= $this->Number->format($command->id) ?></td>
                    <td><?= $command->has('provider') ? $this->Html->link($command->provider->name, ['controller' => 'Providers', 'action' => 'view', $command->provider->id]) : '' ?></td>
                    <td class="actions">
                        <a href="<?= $this->Url->build(['controller' => 'Commands','action' => 'view', $command->id]); ?>"><i class="fas fa-eye"></i></a>&emsp;
                        <!-- <a href="<?= $this->Url->build(['controller' => 'Commands','action' => 'edit', $command->id]); ?>"><i class="fas fa-edit"></i></a>&emsp; -->
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('Premier')) ?>
            <?= $this->Paginator->prev('< ' . __('précédent')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('suivant') . ' >') ?>
            <?= $this->Paginator->last(__('dernier') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
