<?php
$this->Form->setTemplates([

	'input' => '<div class="control "><input class="input" type="{{type}}" name="{{name}}"{{attrs}}/></div>',

	'inputContainer' => '<div info="{{type}}" class="field  {{required}}">{{content}}</div>',
	// Container element used by control() when a field has an error.
	// Label element when inputs are not nested inside the label.
	'label' => '<label class="label" {{attrs}}>{{text}}</label>',
    'button' => '<button class="button is-link mt-3" {{attrs}}>{{text}}</button>',
	// Container for submit buttons.
	'submitContainer' => '<div class="submit field">{{content}}</div>',
	// select element,
	'select' => '<div class="select is-fullwidth"><select name="{{name}}"{{attrs}}>{{content}}</select> </div>',

]);
?>
<style>
a{
    color: grey; 
}
</style>


<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <i class="fas fa-stream"></i> &nbsp; <?= $this->Html->link(__('Liste'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>&emsp;
            <i class="fas fa-sort-alpha-up"></i> &nbsp; <?= $this->Html->link(__('Ajouter une catégorie'), ['controller' => 'Categories','action' => 'add'], ['class' => 'side-nav-item']) ?>&emsp;
            <i class="fas fa-dice"></i> &nbsp; <?= $this->Html->link(__('Ajouter une unité'), ['controller' => 'Units','action' => 'add'], ['class' => 'side-nav-item']) ?>&emsp;
            <i class="fas fa-percentage"></i> &nbsp; <?= $this->Html->link(__('Ajouter un taux tva'), ['controller' => 'Tvas','action' => 'add'], ['class' => 'side-nav-item']) ?>&emsp;
        </div>
    </aside>
    <div class="products column is-full" style="padding-top:5%">
        <?= $this->Form->create($product) ?>
        <fieldset>
            <legend class="subtitle"><?= __('Ajouter un produit') ?></legend>
            <?php
                echo $this->Form->control('name',['label' => 'Dénomination']);
                echo $this->Form->control('category_id', ['label' => 'Catégorie'], ['options' => $categories]);
                echo $this->Form->control('stock',['label' => 'Quantité']);
                echo $this->Form->control('unit_id',['label' => 'Unité'], ['options' => $units]);
                echo $this->Form->control('tva_id',['label' => 'Taux de TVA'], ['options' => $tvas]);
                // echo $this->Form->control('commands._ids', ['options' => $commands],['label' => 'Prénom']);
                // echo $this->Form->control('providers._ids', ['options' => $providers]);
            ?>
        </fieldset>
        <?= $this->Form->button(__('Créer')) ?>
        <?= $this->Form->end() ?>
    </div>
</div>



