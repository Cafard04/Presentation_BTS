<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Product[]|\Cake\Collection\CollectionInterface $products
 */
?>

<style>
a{
    color: grey; 
}
</style>


<div class="products index content">
    <aside class="column">
        <div class="side-nav">
        <i class="fas fa-cart-plus"></i> &nbsp; <?= $this->Html->link(__('Ajouter'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>&emsp;
        </div>
    </aside>

    <h3><?= __('Produits') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id') ?></th>
                    <th><?= $this->Paginator->sort('Dénomination') ?></th>
                    <th><?= $this->Paginator->sort('Catégorie') ?></th>
                    <th><?= $this->Paginator->sort('Quantité') ?></th>
                    <th><?= $this->Paginator->sort('Unité') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($products as $product): ?>
                <tr>
                    <td><?= $this->Number->format($product->id) ?></td>
                    <td><?= h($product->name) ?></td>
                    <td><?= $product->has('category') ? $this->Html->link($product->category->name, ['controller' => 'Categories', 'action' => 'view', $product->category->id]) : '' ?></td>
                    <td><?= $this->Number->format($product->stock) ?></td>
                    <td><?= $product->has('unit') ? $this->Html->link($product->unit->name, ['controller' => 'Units', 'action' => 'view', $product->unit->id]) : '' ?></td>
                    <td class="actions">
                        <a href="<?= $this->Url->build(['controller' => 'Products','action' => 'view', $product->id]); ?>"><i class="fas fa-eye"></i></a>&emsp;
                        <a href="<?= $this->Url->build(['controller' => 'Products','action' => 'edit', $product->id]); ?>"><i class="fas fa-edit"></i></a>&emsp;
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
