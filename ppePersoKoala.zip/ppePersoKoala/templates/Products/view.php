<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Product $product
 */
?>

<style>
a{
    color: grey; 
}
</style>



<div class="row">
    <aside class="column">
        <div class="side-nav pl-3">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <i class="fas fa-edit" ></i> &nbsp; <?= $this->Html->link(__('Editer'), ['action' => 'edit', $product->id], ['class' => 'side-nav-item']) ?> &emsp;
            <i class="fas fa-trash"></i> &nbsp; <?= $this->Form->postLink(__('Supprimer'), ['action' => 'delete', $product->id], ['confirm' => __('Etes vous certain de vouloir supprimer le produit {0} ?', $product->name), 'class' => 'side-nav-item']) ?>&emsp;
            <i class="fas fa-stream"></i> &nbsp; <?= $this->Html->link(__('Liste'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>&emsp;
            <i class="fas fa-cart-plus"></i> &nbsp; <?= $this->Html->link(__('Créer'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="products view content" style="margin:15px; padding-top:5%">
            <h3><?= h($product->name) ?></h3>
            <table>
                <tr>
                    <th><?= __('Dénomination') ?></th>
                    <td><?= h($product->name) ?></td>
                </tr>
                <tr>
                    <th><?= __('Catégorie') ?></th>
                    <td><?= $product->has('category') ? $this->Html->link($product->category->name, ['controller' => 'Categories', 'action' => 'view', $product->category->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Unité') ?></th>
                    <td><?= $product->has('unit') ? $this->Html->link($product->unit->name, ['controller' => 'Units', 'action' => 'view', $product->unit->id]) : '' ?></td>
                </tr>
                <tr>
                    <th><?= __('Quantité') ?></th>
                    <td><?= $this->Number->format($product->stock) ?></td>
                </tr>
            </table>
            <hr>
            <div class="related"style="padding-top:5%">
                <h4><?= __('Commande(s) liée(s)') ?></h4>
                <?php if (!empty($product->commands)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Fournissseur') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($product->commands as $commands) : ?>
                        <tr>
                            <td><?= h($commands->id) ?></td>
                            <td><?= h($commands->provider->name) ?></td>
                            <td class="actions">
                                <a href="<?= $this->Url->build(['controller' => 'Commands','action' => 'view', $commands->id]); ?>"><i class="fas fa-eye"></i></a>&emsp;
                                <a href="<?= $this->Url->build(['controller' => 'Commands','action' => 'edit', $commands->id]); ?>"><i class="fas fa-edit"></i></a>&emsp;
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
            <hr>
            <!-- <div class="related"style="padding-top:5%">
                <h4><?= __('Fournisseur(s) lié(s)') ?></h4>
                <?php if (!empty($product->providers)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Name') ?></th>
                            <th><?= __('Prix (du fournisseur)') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($product->providers as $providers) : ?>
                        <tr>
                            <td><?= h($providers->id) ?></td>
                            <td><?= h($providers->name) ?></td>
                            <td><?= h($providers->_joinData->price) ?> €</td>
                            <td class="actions">
                                <a href="<?= $this->Url->build(['controller' => 'Providers','action' => 'view', $providers->id]); ?>"><i class="fas fa-eye"></i></a>&emsp;
                                <a href="<?= $this->Url->build(['controller' => 'Providers','action' => 'edit', $providers->id]); ?>"><i class="fas fa-edit"></i></a>&emsp;
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div> -->
        </div>
    </div>
</div>
