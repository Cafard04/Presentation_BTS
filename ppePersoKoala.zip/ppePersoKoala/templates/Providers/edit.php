<?php
$this->Form->setTemplates([

	'input' => '<div class="control "><input class="input" type="{{type}}" name="{{name}}"{{attrs}}/></div>',

	'inputContainer' => '<div info="{{type}}" class="field  {{required}}">{{content}}</div>',
	// Container element used by control() when a field has an error.
	// Label element when inputs are not nested inside the label.
	'label' => '<label class="label" {{attrs}}>{{text}}</label>',
    'button' => '<button class="button is-link mt-3" {{attrs}}>{{text}}</button>',
	// Container for submit buttons.
	'submitContainer' => '<div class="submit field">{{content}}</div>',
	// select element,
	'select' => '<div class="select is-fullwidth"><select name="{{name}}"{{attrs}}>{{content}}</select> </div>',

]);
?>
<style>
a{
    color: grey; 
}
</style>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <i class="fas fa-trash"></i> &nbsp; <?= $this->Form->postLink(__('Supprimer'), ['action' => 'delete', $provider->id], ['confirm' => __('Etes vous certain de vouloir supprimer le fournisseur {0} ?', $provider->name), 'class' => 'side-nav-item']) ?>&emsp;
            <i class="fas fa-stream"></i> &nbsp; <?= $this->Html->link(__('Liste'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>&emsp;
            <i class="fas fa-user-tie"></i> &nbsp; <?= $this->Html->link(__('Créer'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="providers column is-full" style="padding-top:5%">
            <?= $this->Form->create($provider) ?>
            <fieldset>
                <legend class="subtitle"><?= __('Editer le fournisseur') ?></legend>
                <?php
                    echo $this->Form->control('name', ['label' => 'Nom']);
                    echo $this->Form->control('products._ids', ['label' => 'Produit(s)'], ['options' => $products]);
                    echo $this->Form->control('products._joinData.price', ['label' => 'Prix unitaire']);
                
               ?>
            </fieldset>
            <?= $this->Form->button(__('Modifier')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
