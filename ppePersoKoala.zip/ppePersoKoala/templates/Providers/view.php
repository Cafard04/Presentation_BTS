<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Provider $provider
 */
?>

<style>
a{
    color: grey; 
}
</style>



<div class="row">
    <aside class="column">
        <div class="side-nav pl-3">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <i class="fas fa-edit" ></i> &nbsp; <?= $this->Html->link(__('Editer'), ['action' => 'edit', $provider->id], ['class' => 'side-nav-item']) ?> &emsp;
            <i class="fas fa-trash"></i> &nbsp; <?= $this->Form->postLink(__('Supprimer'), ['action' => 'delete', $provider->id], ['confirm' => __('Etes vous certain de vouloir supprimer le fournisseur {0} ?', $provider->name), 'class' => 'side-nav-item']) ?>&emsp;
            <i class="fas fa-stream"></i> &nbsp; <?= $this->Html->link(__('Liste'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>&emsp;
            <i class="fas fa-user-tie"></i> &nbsp; <?= $this->Html->link(__('Créer'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="providers view content" style="margin:15px; padding-top:5%">
            <table>
                <tr>
                    <th><?= __('Nom') ?></th>
                    <td><?= h($provider->name) ?></td>
                </tr>
            </table>
            <hr>
            <div class="related"style="padding-top:5%">
                <h4><?= __('Produit(s) lié(s)') ?></h4>
                <?php if (!empty($provider->products)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Nom') ?></th>
                            <th><?= __('Quantité disponible') ?></th>
                            <th><?= __('Prix unitaire') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($provider->products as $products) : ?>
                        <tr>
                            <td><?= h($products->name) ?></td>
                            <td><?= h($products->stock) ?></td>
                            <td><?= h($products->_joinData->price) ?> €</td>
                            <td class="actions">
                                <a href="<?= $this->Url->build(['controller' => 'ProductsProviders','action' => 'view',$provider->id, $products->id]); ?>"><i class="fas fa-eye"></i></a>&emsp;
                                <a href="<?= $this->Url->build(['controller' => 'ProductsProviders','action' => 'edit',$provider->id, $products->id]); ?>"><i class="fas fa-edit"></i></a>&emsp;
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
            <hr>
            <div class="related"style="padding-top:5%">
                <h4><?= __('Commande(s) liée(s)') ?></h4>
                <?php if (!empty($provider->commands)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Id') ?></th>
                            <th><?= __('Provider Id') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($provider->commands as $commands) : ?>
                        <tr>
                            <td><?= h($commands->id) ?></td>
                            <td><?= h($commands->provider_id) ?></td>
                            <td class="actions">
                                <a href="<?= $this->Url->build(['controller' => 'Commands','action' => 'view', $commands->id]); ?>"><i class="fas fa-eye"></i></a>&emsp;
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
