<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Unit $unit
 */
?>

<style>
a{
    color: grey; 
}
</style>

<div class="row">
<aside class="column">
        <div class="side-nav pl-3">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <i class="fas fa-edit" ></i> &nbsp; <?= $this->Html->link(__('Editer'), ['action' => 'edit', $unit->id], ['class' => 'side-nav-item']) ?> &emsp;
            <i class="fas fa-trash"></i> &nbsp; <?= $this->Form->postLink(__('Supprimer'), ['action' => 'delete', $unit->id], ['confirm' => __('Etes vous certain de vouloir supprimer l\'unité {0} ?', $unit->name), 'class' => 'side-nav-item']) ?>&emsp;
            <i class="fas fa-stream"></i> &nbsp; <?= $this->Html->link(__('Liste'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>&emsp;
            <i class="fas fa-dice"></i> &nbsp; <?= $this->Html->link(__('Créer'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="units view content" style="margin:15px; padding-top:5%">
            <table>
                <tr>
                    <th><?= __('Dénomination') ?></th>
                    <td><?= h($unit->name) ?></td>
                </tr>
            </table>
            <hr>
            <div class="related" style="padding-top:5%">
                <h4><?= __('Produits liés') ?></h4>
                <?php if (!empty($unit->products)) : ?>
                <div class="table-responsive">
                    <table>
                        <tr>
                            <th><?= __('Dénomination') ?></th>
                            <th><?= __('Numéro de catégorie') ?></th>
                            <th><?= __('Quantité') ?></th>
                            <th class="actions"><?= __('Actions') ?></th>
                        </tr>
                        <?php foreach ($unit->products as $products) : ?>
                        <tr>
                            <td><?= h($products->name) ?></td>
                            <td><?= h($products->category_id) ?></td>
                            <td><?= h($products->stock) ?></td>
                            <td class="actions">
                                <a href="<?= $this->Url->build(['controller' => 'Products','action' => 'view', $products->id]); ?>"><i class="fas fa-eye"></i></a>&emsp;
                                <a href="<?= $this->Url->build(['controller' => 'Products','action' => 'edit', $products->id]); ?>"><i class="fas fa-edit"></i></a>&emsp;
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
