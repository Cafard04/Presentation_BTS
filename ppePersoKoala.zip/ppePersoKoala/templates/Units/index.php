<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Unit[]|\Cake\Collection\CollectionInterface $units
 */
?>
<style>
a{
    color: grey; 
}
</style>


<div class="units index content">
<aside class="column">
        <div class="side-nav">
        <i class="fas fa-dice"></i> &nbsp; <?= $this->Html->link(__('Ajouter'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>&emsp;
        </div>
    </aside>
    <h3><?= __('Unités') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id') ?></th>
                    <th><?= $this->Paginator->sort('name') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($units as $unit): ?>
                <tr>
                    <td><?= $this->Number->format($unit->id) ?></td>
                    <td><?= h($unit->name) ?></td>
                    <td class="actions">
                        <a href="<?= $this->Url->build(['controller' => 'Units','action' => 'view', $unit->id]); ?>"><i class="fas fa-eye"></i></a>&emsp;
                        <a href="<?= $this->Url->build(['controller' => 'Units','action' => 'edit', $unit->id]); ?>"><i class="fas fa-edit"></i></a>&emsp;
                        
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
