<?php
declare(strict_types=1);

namespace App\Controller;

use Cake\ORM\TableRegistry;
/**
 * ProductsProviders Controller
 *
 * @property \App\Model\Table\ProductsProvidersTable $ProductsProviders
 * @method \App\Model\Entity\ProductsProvider[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class ProductsProvidersController extends AppController
{

    public function isAuthorized($user)
    {
       
        if ($this->request->getParam('action') === 'view' && ( (int)$this->request->getParam('pass')[0] === $this->Auth->user('id') || $user['role_id'] === 1 || $user['role_id'] === 2)) {
            return true;
        }
        if($this->request->getParam('action') === 'delete' && ( $user['role_id'] === 1 || $user['role_id'] === 2)){
            return true;
        }
        if ($this->request->getParam('action') === 'edit' && ( (int)$this->request->getParam('pass')[0] === $this->Auth->user('id') || $user['role_id'] === 1 || $user['role_id'] === 2)) {
            return true;
        }
        if ($this->request->getParam('action') === 'logout') {
            return true;
        }
        if ($this->request->getParam('action') === 'add' && ( $user['role_id'] === 1 || $user['role_id'] === 2)) {
            return true;
        }
        if ($this->request->getParam('action') === 'index' && ( $user['role_id'] === 1 || $user['role_id'] === 2)) {
            return true;
        }
        return false;
    }
        
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */

     // PAGE INUTILE

    // public function index()
    // {
    //     $this->viewBuilder()->setLayout('menu');
    //     $this->paginate = [
    //         'contain' => ['Providers', 'Products', 'Tvas'],
    //     ];
    //     $productsProviders = $this->paginate($this->ProductsProviders);

    //     $this->set(compact('productsProviders'));
    // }

    /**
     * View method
     *
     * @param string|null $id Products Provider id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null, $product = null)
    {
        $this->viewBuilder()->setLayout('menu');
        $q = TableRegistry::getTableLocator()->get('ProductsProviders');
        $productsProvider = $q->get([$id,$product], [
            'contain' => ['Providers', 'Products', 'Tvas'],
        ]);

        $this->set(compact('productsProvider'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $this->viewBuilder()->setLayout('menu');
        $productsProvider = $this->ProductsProviders->newEmptyEntity();
        if ($this->request->is('post')) {
            $productsProvider = $this->ProductsProviders->patchEntity($productsProvider, $this->request->getData());
            if ($this->ProductsProviders->save($productsProvider)) {
                $this->Flash->success(__('The products provider has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The products provider could not be saved. Please, try again.'));
        }
        $providers = $this->ProductsProviders->Providers->find('list', ['limit' => 200]);
        $products = $this->ProductsProviders->Products->find('list', ['limit' => 200]);
        $tvas = $this->ProductsProviders->Tvas->find('list', ['limit' => 200]);
        $this->set(compact('productsProvider', 'providers', 'products', 'tvas'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Products Provider id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null, $product = null)
    {
        $this->viewBuilder()->setLayout('menu');
        $q = TableRegistry::getTableLocator()->get('ProductsProviders');
        $productsProvider = $q->find('all')->where([
            'provider_id' => $id,
            'product_id' => $product,
            ])->limit(1)->toArray();
        if ($this->request->is(['patch', 'post', 'put'])) {
            $productsProvider = $q->newEmptyEntity();
            $productsProvider->provider_id = $id;
            $productsProvider->product_id = $product;
            $productsProvider->tva_id = $this->request->getData()['tva_id'];
            $productsProvider->price = $this->request->getData()['price'];
             // $productsProvider = $q->patchEntity($productsProvider, $this->request->getData());
            if ($q->save($productsProvider)) {
                $this->Flash->success(__('The products provider has been saved.'));
                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The products provider could not be saved. Please, try again.'));
        }
        $providers = $q->Providers->find('list', ['limit' => 200]);
        $products = $q->Products->find('list', ['limit' => 200]);
        $tvas = $q->Tvas->find('list', ['limit' => 200]);
        $this->set(compact('productsProvider', 'providers', 'products', 'tvas'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Products Provider id.
     * @return \Cake\Http\Response|null|void Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null, $product = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $q = TableRegistry::getTableLocator()->get('ProductsProviders');
        $productsProvider = $q->get([$id,$product]);
        // debug($productsProvider);
        if ($q->delete($productsProvider)) {
            $this->Flash->success(__('The products provider has been deleted.'));
        } else {
            $this->Flash->error(__('The products provider could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
