<?php
declare(strict_types=1);

namespace App\Controller;

/**
 * Products Controller
 *
 * @property \App\Model\Table\ProductsTable $Products
 * @method \App\Model\Entity\Product[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class ProductsController extends AppController
{

    public function isAuthorized($user)
    {
       
        if ($this->request->getParam('action') === 'view' && ( (int)$this->request->getParam('pass')[0] === $this->Auth->user('id') || $user['role_id'] === 1 || $user['role_id'] === 2)) {
            return true;
        }
        if($this->request->getParam('action') === 'delete' && ( $user['role_id'] === 1 || $user['role_id'] === 2)){
            return true;
        }
        if ($this->request->getParam('action') === 'edit' && ( (int)$this->request->getParam('pass')[0] === $this->Auth->user('id') || $user['role_id'] === 1 || $user['role_id'] === 2)) {
            return true;
        }
        if ($this->request->getParam('action') === 'logout') {
            return true;
        }
        if ($this->request->getParam('action') === 'add' && ( $user['role_id'] === 1 || $user['role_id'] === 2)) {
            return true;
        }
        if ($this->request->getParam('action') === 'index' && ( $user['role_id'] === 1 || $user['role_id'] === 2)) {
            return true;
        }
        return false;
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $this->viewBuilder()->setLayout('menu');
        $this->paginate = [
            'contain' => ['Categories', 'Units', 'Tvas'],
        ];
        $products = $this->paginate($this->Products);

        $this->set(compact('products'));
    }

    /**
     * View method
     *
     * @param string|null $id Product id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $this->viewBuilder()->setLayout('menu');
        $product = $this->Products->get($id, [
            'contain' => ['Categories', 'Units', 'Tvas', 'Commands', 'Commands.Providers'],
        ]);

        $this->set(compact('product'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $this->viewBuilder()->setLayout('menu');
        $product = $this->Products->newEmptyEntity();
        if ($this->request->is('post')) {
            $product = $this->Products->patchEntity($product, $this->request->getData());
            if ($this->Products->save($product)) {
                $this->Flash->success(__('The product has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The product could not be saved. Please, try again.'));
        }
        $categories = $this->Products->Categories->find('list', ['limit' => 200]);
        $units = $this->Products->Units->find('list', ['limit' => 200]);
        $tvas = $this->Products->Tvas->find('list', ['limit' => 200]);
        $commands = $this->Products->Commands->find('list', ['limit' => 200]);
        $providers = $this->Products->Providers->find('list', ['limit' => 200]);
        $this->set(compact('product', 'categories', 'units', 'tvas', 'commands', 'providers'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Product id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $this->viewBuilder()->setLayout('menu');
        $product = $this->Products->get($id, [
            'contain' => ['Commands', 'Providers'],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $product = $this->Products->patchEntity($product, $this->request->getData());
            if ($this->Products->save($product)) {
                $this->Flash->success(__('The product has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The product could not be saved. Please, try again.'));
        }
        $categories = $this->Products->Categories->find('list', ['limit' => 200]);
        $units = $this->Products->Units->find('list', ['limit' => 200]);
        $tvas = $this->Products->Tvas->find('list', ['limit' => 200]);
        $commands = $this->Products->Commands->find('list', ['limit' => 200]);
        $providers = $this->Products->Providers->find('list', ['limit' => 200]);
        $this->set(compact('product', 'categories', 'units', 'tvas', 'commands', 'providers'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Product id.
     * @return \Cake\Http\Response|null|void Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->viewBuilder()->setLayout('menu');
        $this->request->allowMethod(['post', 'delete']);
        $product = $this->Products->get($id);
        if ($this->Products->delete($product)) {
            $this->Flash->success(__('The product has been deleted.'));
        } else {
            $this->Flash->error(__('The product could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
