<?php
declare(strict_types=1);

namespace App\Controller;
use Cake\ORM\Locator\LocatorAwareTrait;
/**
 * Commands Controller
 *
 * @property \App\Model\Table\CommandsTable $Commands
 * @method \App\Model\Entity\Command[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class CommandsController extends AppController
{

    public function isAuthorized($user)
    {
       
        if ($this->request->getParam('action') === 'view' && ( (int)$this->request->getParam('pass')[0] === $this->Auth->user('id') || $user['role_id'] === 1 || $user['role_id'] === 2)) {
            return true;
        }
        if($this->request->getParam('action') === 'delete' && ( $user['role_id'] === 1 || $user['role_id'] === 2)){
            return true;
        }
        if ($this->request->getParam('action') === 'edit' && ( (int)$this->request->getParam('pass')[0] === $this->Auth->user('id') || $user['role_id'] === 1 || $user['role_id'] === 2)) {
            return true;
        }
        if ($this->request->getParam('action') === 'logout') {
            return true;
        }
        if ($this->request->getParam('action') === 'add' && ( $user['role_id'] === 1 || $user['role_id'] === 2)) {
            return true;
        }
        if ($this->request->getParam('action') === 'index' && ( $user['role_id'] === 1 || $user['role_id'] === 2)) {
            return true;
        }
        return false;
    }

    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $this->viewBuilder()->setLayout('menu');
        $this->paginate = [
            'contain' => ['Providers'],
        ];
        $commands = $this->paginate($this->Commands);

        $this->set(compact('commands'));
    }

    /**
     * View method
     *
     * @param string|null $id Command id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $this->viewBuilder()->setLayout('menu');
        $command = $this->Commands->get($id, [
            'contain' => ['Providers', 'Products','Products.Categories','Products.Units'],
        ]);

        $this->set(compact('command'));
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add($provider = null)
    {
        $this->viewBuilder()->setLayout('menu');
        $command = $this->Commands->newEmptyEntity();
        $command->provider_id = $provider;

        $providers = $this->Commands->Providers->get($provider, [
            'contain' => ['Products' => function ($q) {
                return $q->where(['ProductsProviders.price >' => 0]);
            }],
        ]);
            $idList = [];
            $priceList = [];
            if(sizeof($providers->products) == 0){
                $this->Flash->error(__("Ce fournisseur n'a aucun produit avec des prix !"));
                return $this->redirect(['controller' => 'providers','action' => 'index']);
            }
            foreach ($providers->products as $p){
                $idList[] = $p->id;
                $priceList[$p->id] = $p->_joinData->price;    
            }
        $products = $this->Commands->Products->find()->where([
            'id IN' => $idList 
        ])->combine('id', 'name');
        if ($this->request->is('post')) {
            $command = $this->Commands->patchEntity($command, $this->request->getData());
            foreach ($command->products as $p) {
                $p->_joinData->price = $p->_joinData->qtt * $priceList[$p->id];
            }
            if ($this->Commands->save($command)) {
                $this->Flash->success(__('The command has been saved.'));
                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The command could not be saved. Please, try again.'));
        }
        // $providers = $this->Commands->Providers->find('list', ['limit' => 200]);

        $this->set(compact('command', 'providers','products'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Command id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */



// UNE COMMANDE NE PEUT PAS ETRE EDITé 

    // public function edit($id = null)
    // {
    //     $this->viewBuilder()->setLayout('menu');
    //     $command = $this->Commands->get($id, [
    //         'contain' => ['Products'],
    //     ]);
    //     if ($this->request->is(['patch', 'post', 'put'])) {
    //         $command = $this->Commands->patchEntity($command, $this->request->getData());
    //         if ($this->Commands->save($command)) {
    //             $this->Flash->success(__('The command has been saved.'));

    //             return $this->redirect(['action' => 'index']);
    //         }
    //         $this->Flash->error(__('The command could not be saved. Please, try again.'));
    //     }
    //     $providers = $this->Commands->Providers->find('list', ['limit' => 200]);
    //     $products = $this->Commands->Products->find('list', ['limit' => 200]);
    //     $this->set(compact('command', 'providers', 'products'));
    // }

    /**
     * Delete method
     *
     * @param string|null $id Command id.
     * @return \Cake\Http\Response|null|void Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->viewBuilder()->setLayout('menu');
        $this->request->allowMethod(['post', 'delete']);
        $command = $this->Commands->get($id);
        if ($this->Commands->delete($command)) {
            $this->Flash->success(__('The command has been deleted.'));
        } else {
            $this->Flash->error(__('The command could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
