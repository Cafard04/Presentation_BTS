<?php
namespace App\Controller;


use Cake\Event\Event;
use App\Controller\AppController;

use Cake\Event\EventInterface;
/**
 * Users Controller
 *
 * @property \App\Model\Table\UsersTable $Users
 *
 * @method \App\Model\Entity\User[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class UsersController extends AppController
{


    public function beforeFilter(EventInterface $event)
    {
        parent::beforeFilter($event);
        $this->Auth->allow(['login','accueil','register']);
    }

    public function isAuthorized($user)
    {
       
        if ($this->request->getParam('action') === 'view' && ( (int)$this->request->getParam('pass')[0] === $this->Auth->user('id') || $user['role_id'] === 1 )) {
            return true;
        }
        if($this->request->getParam('action') === 'delete' && ( $user['role_id'] === 1 )){
            return true;
        }
        if ($this->request->getParam('action') === 'edit' && ( (int)$this->request->getParam('pass')[0] === $this->Auth->user('id') || $user['role_id'] === 1 )) {
            return true;
        }
        if ($this->request->getParam('action') === 'logout') {
            return true;
        }
        if ($this->request->getParam('action') === 'add' && ( $user['role_id'] === 1 )) {
            return true;
        }
        if ($this->request->getParam('action') === 'index' && ( $user['role_id'] === 1 )) {
            return true;
        }
        if ($this->request->getParam('action') === 'stat' && ( $user['role_id'] === 1 )) {
            return true;
        }
        return false;
    }


    public function accueil(){
        $this->viewBuilder()->setLayout('koala');
    }
    
    public function register(){
        $this->viewBuilder()->setLayout('koala-cnx');
        
        
        
                $user = $this->Users->newEntity();
        if ($this->request->is('post')) {
            $user = $this->Users->patchEntity($user, $this->request->getData());
            $user->role_id = 3;
            $user->login = $user->name.$user->firstname;
            
            if ($this->Users->save($user)) {
                $this->Flash->success(__('The user has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            debug($this->Users->save($user));
            $this->Flash->error(__('The user could not be saved. Please, try again.'));
        }
        $this->set(compact('user'));
        
    }


    

    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {

        $this->viewBuilder()->setLayout('menu');
        $this->paginate = [
            'contain' => ['Roles'],
        ];
        $users = $this->paginate($this->Users);

        $this->set(compact('users'));
    }





    public function login()
    {
        $this->viewBuilder()->setLayout('koala-cnx');
        if ($this->request->is('post')) {
            $user = $this->Auth->identify();

            if ($user) {
                $usertmp = $this->Users->get($user['id']);
                $this->Auth->setUser($user);
                $query =  $this->Users->Roles->find()->select(['name'])->where(['id =' => $user['role_id']])->first();
                $this->request->getSession()->write('user.role', $query->name);

                return $this->redirect(['controller'=>'Users','action'=>'accueil']);
            } else {
                $this->Flash->error(__("Nom d'utilisateur ou mot de passe incorrect"));
            }
        }
    }

    public function logout()
    {
        $this->redirect($this->Auth->logout());
    }





    /**
     * View method
     *
     * @param string|null $id User id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        //  $status = $this->Users->Files->Status->find('list', ['limit' => 200])->toArray();
        
        // $this->set('status',$status);
        
        $this->viewBuilder()->setLayout('menu');
        $user = $this->Users->get($id, [
            'contain' => ['Roles'],
        ]);

        $this->set('user', $user);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $user = $this->Users->newEmptyEntity();
        $this->viewBuilder()->setLayout('menu');
        if ($this->request->is('post')) {
            $user = $this->Users->patchEntity($user, $this->request->getData());
            if ($this->Users->save($user)) {
                $this->Flash->success(__('The user has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
 
            $this->Flash->error(__('The user could not be saved. Please, try again.'));
        }
        // $cities = $this->Users->Cities->find('list', ['limit' => 200]);
        $roles = $this->Users->Roles->find('list', ['limit' => 200]);
        $this->set(compact('user', 'roles'));
    }

    /**
     * Edit method
     *
     * @param string|null $id User id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $this->viewBuilder()->setLayout('menu');
        $user = $this->Users->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $user = $this->Users->patchEntity($user, $this->request->getData());
            if ($this->Users->save($user)) {
                $this->Flash->success(__('The user has been saved.'));

                return $this->redirect(['action' => 'index']);
            }

            $this->Flash->error(__('The user could not be saved. Please, try again.'));
        }
        // $cities = $this->Users->Cities->find('list', ['limit' => 200]);
        $roles = $this->Users->Roles->find('list', ['limit' => 200]);
        $this->set(compact('user', 'roles'));
    }

    /**
     * Delete method
     *
     * @param string|null $id User id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $user = $this->Users->get($id);
        if ($this->Users->delete($user)) {
            $this->Flash->success(__('The user has been deleted.'));
        } else {
            $this->Flash->error(__('The user could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }


    public function stat(){
        $this->viewBuilder()->setLayout('menu');
        $this->loadModel('Providers'); 
        $data=$this->Providers->query('SELECT COUNT(*) FROM providers');
        $this->set('data',$data);
    }

}